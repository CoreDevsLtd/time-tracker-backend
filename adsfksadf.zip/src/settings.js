export default {
  'port': process.env.PORT || 4000,
  'origin': [
    '*'
  ],
  'useHTTP2': false,
  'SMTP_HOST': '',
  'SMTP_PORT': '',
  'SMTP_USER': '',
  'SMTP_PASSWORD': '',
  'EMAIL_NAME': '',
  'EMAIL_FROM': 'from@example.com',
  'MONGODB_URL': 'mongodb+srv://parvejhossain:parvejhossain@cluster0.jkdxpyh.mongodb.net/TimeTracker',
  'TOKEN_KEY': 'token',
  'SECRET': 'Z87QR98n034r3rsheif7939rufs9uf3w4ru2lxx2kallsflskdfksfpq'
};