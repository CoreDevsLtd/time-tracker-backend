export const schemas = {
  demo: {
    name: 'string'
  }
};